using UnityEngine;

public class VibrationManager : MonoBehaviour
{
    public static VibrationManager singleton { get; private set; }

    [Header("Vibration Settings")]
    [SerializeField] private bool vibracionActiva = true;

    [Header("Presets (en milisegundos)")]
    [SerializeField] private long duracionPoco = 50;
    [SerializeField] private long duracionMedio = 100;
    [SerializeField] private long duracionAlto = 200;

    [Header("Debug")]
    [SerializeField] private bool showDebugLogs = false;

#if UNITY_ANDROID && !UNITY_EDITOR
    private AndroidJavaObject vibrator;
#endif

    private void Awake()
    {
        // Singleton
        if (singleton != null && singleton != this)
        {
            Destroy(gameObject);
            return;
        }

        singleton = this;
        //DontDestroyOnLoad(gameObject);

        InicializarVibrador();
    }

    private void InicializarVibrador()
    {
#if UNITY_ANDROID && !UNITY_EDITOR
        try
        {
            // Obtener el contexto de Unity
            AndroidJavaClass unityPlayer = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
            AndroidJavaObject currentActivity = unityPlayer.GetStatic<AndroidJavaObject>("currentActivity");
            
            // Obtener el servicio de vibraci�n
            AndroidJavaObject context = currentActivity.Call<AndroidJavaObject>("getApplicationContext");
            vibrator = context.Call<AndroidJavaObject>("getSystemService", "vibrator");
            
            if (showDebugLogs)
                Debug.Log("VibrationManager: Vibrador inicializado correctamente");
        }
        catch (System.Exception e)
        {
            Debug.LogError("VibrationManager: Error al inicializar vibrador - " + e.Message);
        }
#else
        if (showDebugLogs)
            Debug.Log("VibrationManager: No est� en Android, vibraci�n simulada");
#endif
    }

    // M�todo principal para vibrar con duraci�n personalizada
    public void Vibrar(long duracionMilisegundos)
    {
        if (!vibracionActiva)
        {
            if (showDebugLogs)
                Debug.Log("VibrationManager: Vibraci�n desactivada");
            return;
        }

#if UNITY_ANDROID && !UNITY_EDITOR
        try
        {
            if (vibrator != null)
            {
                vibrator.Call("vibrate", duracionMilisegundos);
                
                if (showDebugLogs)
                    Debug.Log($"VibrationManager: Vibrando por {duracionMilisegundos}ms");
            }
        }
        catch (System.Exception e)
        {
            Debug.LogError("VibrationManager: Error al vibrar - " + e.Message);
        }
#else
        // Usar la vibraci�n simple de Unity como fallback (solo funciona en m�viles)
        Handheld.Vibrate();

        if (showDebugLogs)
            Debug.Log($"VibrationManager: Vibraci�n simulada ({duracionMilisegundos}ms)");
#endif
    }

    // M�todos predefinidos
    [ContextMenu("Vibrar Poco")]
    public void VibrarPoco()
    {
        Vibrar(duracionPoco);
    }

    [ContextMenu("Vibrar Medio")]
    public void VibrarMedio()
    {
        Vibrar(duracionMedio);
    }

    [ContextMenu("Vibrar Alto")]
    public void VibrarAlto()
    {
        Vibrar(duracionAlto);
    }

    // M�todo para cancelar la vibraci�n (Android 8.0+)
    public void CancelarVibracion()
    {
#if UNITY_ANDROID && !UNITY_EDITOR
        try
        {
            if (vibrator != null)
            {
                vibrator.Call("cancel");
                
                if (showDebugLogs)
                    Debug.Log("VibrationManager: Vibraci�n cancelada");
            }
        }
        catch (System.Exception e)
        {
            Debug.LogError("VibrationManager: Error al cancelar vibraci�n - " + e.Message);
        }
#endif
    }

    // M�todo para activar/desactivar la vibraci�n
    public void SetVibracionActiva(bool activa)
    {
        vibracionActiva = activa;

        if (showDebugLogs)
            Debug.Log($"VibrationManager: Vibraci�n {(activa ? "activada" : "desactivada")}");
    }

    // M�todo para verificar si la vibraci�n est� activa
    public bool EstaVibracionActiva()
    {
        return vibracionActiva;
    }

    // M�todo para cambiar los presets en runtime
    public void SetDuracionPoco(long duracion)
    {
        duracionPoco = duracion;
    }

    public void SetDuracionMedio(long duracion)
    {
        duracionMedio = duracion;
    }

    public void SetDuracionAlto(long duracion)
    {
        duracionAlto = duracion;
    }

    // M�todo para obtener las duraciones actuales
    public long GetDuracionPoco() => duracionPoco;
    public long GetDuracionMedio() => duracionMedio;
    public long GetDuracionAlto() => duracionAlto;
}